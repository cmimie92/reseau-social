import {FollowersService } from '../../services/Followers.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {
  followers: any[];
  nombre;

  constructor(private service: FollowersService) { 

      

  }

  ngOnInit() {
  this.followers=this.service.getFollowers();
  console.log(this.followers);
   this.nombre=this.followers.length;
  }

//ngOnInit() {
 //   this.service.getAll()
//      .subscribe(followers => this.followers = followers);-->
 // }





}

