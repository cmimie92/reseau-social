import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajout-ami',
  templateUrl: './ajout-ami.component.html',
  styleUrls: ['./ajout-ami.component.css']
})
export class AjoutAmiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
